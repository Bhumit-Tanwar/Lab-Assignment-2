package model;

public abstract class Person {
    protected String name;
    protected String email;

    public Person(String name, String email) {
        this.name = name;
        this.email = email;
    }

    // Abstract method (must be implemented in subclass)
    public abstract void displayInfo();

    // Common getter methods
    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }
}
