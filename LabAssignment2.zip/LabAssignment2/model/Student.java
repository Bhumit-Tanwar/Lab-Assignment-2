package model;

public class Student extends Person {
    private int rollNo;
    private String course;
    private double marks;
    private char grade;

    // Constructor
    public Student(int rollNo, String name, String email, String course, double marks) {
        super(name, email);
        this.rollNo = rollNo;
        this.course = course;
        this.marks = marks;
        calculateGrade();
    }

    // Overloaded constructor (method overloading demonstration)
    public Student(int rollNo, String name, String email, String course) {
        this(rollNo, name, email, course, 0.0);
    }

    // Grade calculation logic
    public void calculateGrade() {
        if (marks >= 90) grade = 'A';
        else if (marks >= 75) grade = 'B';
        else if (marks >= 60) grade = 'C';
        else if (marks >= 40) grade = 'D';
        else grade = 'F';
    }

    // Overridden method
    @Override
    public void displayInfo() {
        System.out.println("Student Info:");
        System.out.println("Roll No: " + rollNo);
        System.out.println("Name   : " + name);
        System.out.println("Email  : " + email);
        System.out.println("Course : " + course);
        System.out.println("Marks  : " + marks);
        System.out.println("Grade  : " + grade);
        System.out.println("---------------------------------");
    }

    // Getter methods
    public int getRollNo() {
        return rollNo;
    }
}
