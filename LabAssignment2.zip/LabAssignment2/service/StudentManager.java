package service;

import model.Student;
import java.util.*;

public class StudentManager implements RecordActions {
    private Map<Integer, Student> studentMap = new HashMap<>();

    @Override
    public void addStudent(Student student) {
        if (studentMap.containsKey(student.getRollNo())) {
            System.out.println("❌ Roll number already exists!");
            return;
        }
        studentMap.put(student.getRollNo(), student);
        System.out.println("✅ Student added successfully!");
    }

    @Override
    public void deleteStudent(int rollNo) {
        if (studentMap.remove(rollNo) != null)
            System.out.println("✅ Student deleted successfully.");
        else
            System.out.println("❌ Student not found.");
    }

    @Override
    public void updateStudent(int rollNo, double newMarks) {
        Student s = studentMap.get(rollNo);
        if (s != null) {
            // Polymorphism: calling overridden method
            s = new Student(s.getRollNo(), s.getName(), s.getEmail(), "Updated Course", newMarks);
            studentMap.put(rollNo, s);
            System.out.println("✅ Marks updated successfully!");
        } else {
            System.out.println(" Student not found.");
        }
    }

    @Override
    public Student searchStudent(int rollNo) {
        return studentMap.get(rollNo);
    }

    @Override
    public void viewAllStudents() {
        if (studentMap.isEmpty()) {
            System.out.println("No records found!");
            return;
        }
        for (Student s : studentMap.values()) {
            s.displayInfo();
        }
    }
}
