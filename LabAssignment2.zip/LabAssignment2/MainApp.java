import java.util.Scanner;
import model.Student;
import service.StudentManager;

public class MainApp {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        StudentManager manager = new StudentManager();
        int choice = 0;

        do {
            System.out.println("\n===== Student Management Menu =====");
            System.out.println("1. Add Student");
            System.out.println("2. View All Students");
            System.out.println("3. Update Student Marks");
            System.out.println("4. Delete Student");
            System.out.println("5. Search Student");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");

            try {
                choice = Integer.parseInt(sc.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("❌ Invalid input. Please enter a number 1–6.");
                continue;
            }

            switch (choice) {
                case 1:
                    System.out.print("Enter Roll No: ");
                    int roll = Integer.parseInt(sc.nextLine());
                    System.out.print("Enter Name: ");
                    String name = sc.nextLine();
                    System.out.print("Enter Email: ");
                    String email = sc.nextLine();
                    System.out.print("Enter Course: ");
                    String course = sc.nextLine();
                    System.out.print("Enter Marks: ");
                    double marks = Double.parseDouble(sc.nextLine());
                    Student s = new Student(roll, name, email, course, marks);
                    manager.addStudent(s);
                    break;

                case 2:
                    manager.viewAllStudents();
                    break;

                case 3:
                    System.out.print("Enter Roll No to update: ");
                    int rollToUpdate = Integer.parseInt(sc.nextLine());
                    System.out.print("Enter new marks: ");
                    double newMarks = Double.parseDouble(sc.nextLine());
                    manager.updateStudent(rollToUpdate, newMarks);
                    break;

                case 4:
                    System.out.print("Enter Roll No to delete: ");
                    int rollToDelete = Integer.parseInt(sc.nextLine());
                    manager.deleteStudent(rollToDelete);
                    break;

                case 5:
                    System.out.print("Enter Roll No to search: ");
                    int rollToSearch = Integer.parseInt(sc.nextLine());
                    Student found = manager.searchStudent(rollToSearch);
                    if (found != null) found.displayInfo();
                    else System.out.println("Student not found.");
                    break;

                case 6:
                    System.out.println("Exiting... Goodbye!");
                    break;

                default:
                    System.out.println("Please choose between 1–6.");
            }

        } while (choice != 6);
        sc.close();
    }
}
